The  work on the project was divided equally. Jay and I worked on the project together.
However, Jay focused more heavily on the design aspects of the project, whereas I focused on the backend logic.

The project allows us to search on movies and actors, as well as place reviews on movies.
Upon searching, the Movie and Actor info pages have links to Actors involved and Movie roles respectively. 
Additionally, it allows the user to populate the Actor, Movie, MovieGenre, MovieActor, Director, and MovieDirector tables.
